/**
 * Created by dorbaruch on 11/7/17.
 */


/*
 *  StationMap - Object constructor function
 *  @param _parentElement   -- HTML element in which to draw the visualization
 *  @param _data            -- Array with all stations of the bike-sharing network
 */

HerdImmunity = function(_parentElement, _topoData) {

    this.parentElement = _parentElement;
    this.topoData = _topoData;

    this.initVis();
};


/*
 *  Initialize station map
 */

HerdImmunity.prototype.initVis = function() {
    var vis = this;

    vis.margin = {top: 20, right: 20, bottom: 20, left: 20};

    vis.width = 960 - vis.margin.left - vis.margin.right;
    vis.height = 530 - vis.margin.top - vis.margin.bottom;

    // SVG drawing area
    vis.svg = d3.select("#" + vis.parentElement).append("svg")
        .attr("width", vis.width + vis.margin.left + vis.margin.right)
        .attr("height", vis.height + vis.margin.top + vis.margin.bottom)
        .append("g")
        .attr("transform", "translate(" + vis.margin.left + "," + vis.margin.top + ")");
    /**
    // vis.projection = d3.geoAlbers().center([15, -5]).scale(300).translate([vis.width / 2, vis.height / 2]);
    vis.projection = d3.geoAlbersUsa()
        .scale(vis.width)
        .translate([vis.width / 2, vis.height / 2]);

    vis.path = d3.geoPath()
        .projection(vis.projection);

    vis.usa = vis.topoData.features;

    vis.paths = vis.svg.selectAll("feature")
        .data(vis.usa)
        .enter()
        .append("path")
        .attr("d", vis.path)
        .attr("stroke", "black")
        .attr("stroke-width", 0.5)
        .attr("class", "feature")
        .style("fill", "green");
    **/

    // initialize input boxes
    $("#immunization-rate").val("0.8");
    $("#rate-vaccinated").val("0.1");
    $("#rate-not-vaccinated").val("0.9");

    // bind repopulate button
    $("#repopulate-button").on("click", function() {
       vis.initPopulation();
    });

    vis.initPopulation();
};

HerdImmunity.prototype.initPopulation = function() {
    var immunizationRate = $("#immunization-rate").val();
    var vis = this;
    var rect_width = 30;
    var rect_height = 40;
    var rect;
    vis.population = [];
    vis.totalVaccinated = 0;
    vis.totalUnvaccinated = 0;
    vis.infectedVaccinated = 0;
    vis.infectedUnvaccinated = 0;
    for(var i = 20; i < vis.width; i+=rect_width - 8) {
        var rects_row = [];
        for(var j = 20; j < vis.height; j+= rect_height - 5) {
            // rect = vis.svg.append("rect")
            //     .attr("x", i)
            //     .attr("y", j)
            //     .attr("width", rect_width)
            //     .attr("height", rect_height)
            //     .attr("class", "unprocessed");
            //     if(Math.random() < immunizationRate) {
            //         rect.style("fill", "green");
            //     }
            //     else {
            //         rect.style("fill", "red");
            //     }

            rect = vis.svg.append("svg:image")
                .attr("x", i)
                .attr("y", j)
                .attr("width", rect_width)
                .attr("height", rect_height)
                .attr("class", "unprocessed");

            if(Math.random() < immunizationRate) {
                rect.style("fill", "green");
                rect.attr("xlink:href", "img/green_man.svg");
                vis.totalVaccinated += 1;
            }
            else {
                rect.style("fill", "red");
                rect.attr("xlink:href", "img/red_man.svg");
                vis.totalUnvaccinated += 1;
            }

            rects_row.push(rect);
        }
        vis.population.push(rects_row);
    }

    vis.totalPopulation = vis.totalVaccinated + vis.totalUnvaccinated;

    for(i = 0; i < vis.population.length; i++) {
        for(j = 0; j < vis.population[0].length; j++) {
            bindRun([i, j]);
        }
    }

    function bindRun(pos) {
        vis.population[pos[0]][pos[1]].on("click", function() {
            console.log(pos);
            vis.startSimulation([pos[0], pos[1]]);
        });
    }

    vis.updateResults();
};

HerdImmunity.prototype.updateResults = function() {
    var vis = this;
    // if(total) {
    //     $("#total-population").text(vis.totalPopulation);
    //     $("#total-vaccinated").text(vis.totalVaccinated);
    //     $("#total-unvaccinated").text(vis.totalUnvaccinated);
    // }
        $("#total-infected").text(vis.infectedVaccinated + vis.infectedUnvaccinated);
        $("#infected-vaccinated").text(vis.infectedVaccinated);
        $("#infected-unvaccinated").text(vis.infectedUnvaccinated);

        $("#percent-infected").text((((vis.infectedVaccinated + vis.infectedUnvaccinated) / vis.totalPopulation)
        * 100).toFixed(2));
        $("#percent-vaccinated-infected").text(((vis.infectedVaccinated / vis.totalPopulation) * 100).toFixed(2));
        $("#percent-unvaccinated-infected").text(((vis.infectedUnvaccinated / vis.totalPopulation) * 100).toFixed(2));
        $("#percent-of-infected-vaccinated").text(((vis.infectedVaccinated / (vis.infectedVaccinated + 1 +
        vis.infectedUnvaccinated)) * 100).toFixed(2));
};

HerdImmunity.prototype.startSimulation = function(startPos) {
    var vis = this;
    var rateVaccinated = $("#rate-vaccinated").val();
    var rateNotVaccinated = $("#rate-not-vaccinated").val();
    var startFlag = true;
    function iteratePopulation(curPos) {
        setTimeout(function () {
            if (curPos[0] >= 0 && curPos[0] < vis.population.length && curPos[1] >= 0
                && curPos[1] < vis.population[0].length) {
                var curRect = vis.population[curPos[0]][curPos[1]];
                if(curRect.style("fill") !== "black" && curRect.attr("class") !== "processed") {
                    curRect.attr("class", "processed");
                    if(curRect.style("fill") == "red") {
                        if(Math.random() < rateNotVaccinated || startFlag) {
                            curRect.style("fill", "black");
                            curRect.attr("xlink:href", "img/black_man.svg");
                            vis.infectedUnvaccinated += 1;
                            vis.updateResults(false);
                            recurse(curPos);
                        }
                    }
                    else if (curRect.style("fill") == "green") {
                        if(Math.random() < rateVaccinated || startFlag) {
                            curRect.style("fill", "black");
                            curRect.attr("xlink:href", "img/black_man.svg");
                            vis.infectedVaccinated += 1;
                            vis.updateResults(false);
                            recurse(curPos);
                        }
                    }
                }
            }
            if(startFlag) {
                startFlag = false;
            }
        }, 100);
    }

    function recurse(curPos) {
        iteratePopulation([curPos[0] + 1, curPos[1]]);
        iteratePopulation([curPos[0], curPos[1] + 1]);
        iteratePopulation([curPos[0] - 1, curPos[1]]);
        iteratePopulation([curPos[0], curPos[1] - 1]);
        iteratePopulation([curPos[0] - 1, curPos[1] - 1]);
        iteratePopulation([curPos[0] - 1, curPos[1] + 1]);
        iteratePopulation([curPos[0] + 1, curPos[1] - 1]);
        iteratePopulation([curPos[0] + 1, curPos[1] + 1]);
    }

    iteratePopulation(startPos);
};



/*
 *  Data wrangling
 */

HerdImmunity.prototype.wrangleData = function() {
    var vis = this;

    // Currently no data wrangling/filtering needed
    // vis.displayData = vis.data;

    // Update the visualization
    vis.updateVis();

};


/*
 *  The drawing function
 */

HerdImmunity.prototype.updateVis = function() {

};


