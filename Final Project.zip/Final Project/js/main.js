width = $("#cover").width();
height = 500;

var svg = d3.select("#cover").append("svg")
    .attr("width", width)
    .attr("height", height);

svg.append("svg:image")
    .attr("x", 0)
    .attr("y", 0)
    .attr("class", "try")
    .attr("xlink:href", "img/superhero-kid.jpg");

svg.append("text")
    .text("The Power of Vaccination")
    .attr("x", width/2)
    .attr("text-anchor", "middle")
    .attr("y", height/3 - 40)
    .attr("fill", "black");


// Variable for the visualization instance
var herdImmunity;

// Start application by loading the data
createVis();


function loadData() {

    // TO-DO: LOAD DATA
}


function createVis() {
    d3.json("data/usa.geo.json", function(error, data) {
        herdImmunity = new HerdImmunity("herd-vis", data);
    });
}